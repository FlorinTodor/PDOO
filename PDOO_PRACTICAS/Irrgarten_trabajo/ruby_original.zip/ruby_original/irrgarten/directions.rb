#encoding:utf-8
module Irrgarten
module Directions
  LEFT= :LEFT
  RIGHT= :RIGHT
  UP= :UP
  DOWN= :DOWN
end
end
