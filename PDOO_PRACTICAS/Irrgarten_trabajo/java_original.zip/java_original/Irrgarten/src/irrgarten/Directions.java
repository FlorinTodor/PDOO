package irrgarten;
import java.awt.RenderingHints;
import javax.swing.text.AbstractDocument;

/**
 *
 * @author flo & gabi
 */

  public enum Directions{LEFT,RIGHT,UP,DOWN};
