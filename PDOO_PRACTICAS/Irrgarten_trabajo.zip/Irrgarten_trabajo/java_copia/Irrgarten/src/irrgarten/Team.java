/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

import java.util.ArrayList;

/**
 *
 * @author flo
 */
public class Team {
    private static final int CAPACITY = 10;
    private String name;
    private int numWins=0;
    private ArrayList<Player> players = new ArrayList<Player>();

    public Team(String name, Player leader) {
        this.name = name;
        this.players.add(leader);
    }
    
    public void addNewPlayer(Player player) {
        if (players.size() < CAPACITY) {
            this.players.add(player);
        } else {
            System.err.println("NO CABEN MÁS JUGADORES");
        }

        //VEMOS QUE EN JAVA NO ES NECESEARIO NINGUNA MODIFICACIÓN


    }
}
