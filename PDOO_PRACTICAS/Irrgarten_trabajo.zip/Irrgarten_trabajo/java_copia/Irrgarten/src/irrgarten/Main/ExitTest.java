package irrgarten.Main;
import irrgarten.UI.TextUI;
import irrgarten.controller.Controller;
import irrgarten.Game;
import irrgarten.Directions;

public class ExitTest {
     public static void main(String [] args){
         Game game = new Game(1);
         TextUI textUI = new TextUI();
        Controller controller = new Controller(game, textUI);
         
         
         textUI.showGame(game.getGameState());
         game.nextStep(Directions.RIGHT);
         textUI.showGame(game.getGameState());
         game.nextStep(Directions.DOWN);
         textUI.showGame(game.getGameState());
     }
}
