#encoding:utf-8
require_relative 'dice'
require_relative 'monster'
module Irrgarten

class Examen

@@DATOS_PERSONALES = "FLORIN_EMANUEL_TODOR_GLIGA"

def initialize()
dado_aux = Dice.random_pos(6)
while true
	if dado_aux > 0 && dado_aux <= 6
		@dado = dado_aux
		break
	else
		dado_aux = Dice.random_pos(6)

end
end
end

def self.get_datos_personales
@@DATOS_PERSONALES
end

def get_dado
@dado
end

def lanzar_dado
	puts "ESTUDIANTE #{@@DATOS_PERSONALES} ha obtenido un #{get_dado} en el dado"
end

def promedio_fuerza(monsters)
	#Creamos en monsters el metodo publico de get_strength
	sum =0
	for monster in monsters do
		sum += monster.get_strength
	end
	media = sum / monsters.length
	media
end


end

examen = Examen.new
examen.lanzar_dado
#monster1 = Monster.new("algo",Dice.random_intelligence,Dice.random_strength)
#monster2 = Monster.new("algo2",Dice.random_intelligence,Dice.random_strength)
#puts monster1.get_strength
#puts monster2.get_strength

monsters = Array.new
#monsters.push(monster1)
#monsters.push(monster2)
for i in (0...99)
	monster = Monster.new("mounstruo",Dice.random_intelligence,i+1)
	monsters.push(monster)
end
puts "La media aritimetica es : #{examen.promedio_fuerza(monsters)}"
end

