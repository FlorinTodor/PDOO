#encoding:utf-8
require_relative 'player'


module Irrgarten
class Team
@@MAX_CAPACITY = 10

def initialize(name,leader)
@name = name
@num_wins = 0
@players = Array.new
@players.push(leader)
end

def add_new_player(player)
if @players.lenght < @@MAX_CAPACITY
	@players.push(player)
else
	puts "ERROR"
end
end



end
end
