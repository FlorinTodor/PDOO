package Irrgarten;

public class PlayerSquare {

	private int row;
	private int col;
}
