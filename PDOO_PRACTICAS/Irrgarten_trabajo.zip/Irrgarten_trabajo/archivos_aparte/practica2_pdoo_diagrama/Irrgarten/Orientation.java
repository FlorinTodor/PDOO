package Irrgarten;

public enum Orientation {
	VERTICAL, HORIZONTAL
}
