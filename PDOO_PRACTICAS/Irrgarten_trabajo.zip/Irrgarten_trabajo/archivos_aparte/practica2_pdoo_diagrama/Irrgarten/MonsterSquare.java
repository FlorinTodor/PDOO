package Irrgarten;

public class MonsterSquare {

	private int row;
	private int col;
	private char content;
}
