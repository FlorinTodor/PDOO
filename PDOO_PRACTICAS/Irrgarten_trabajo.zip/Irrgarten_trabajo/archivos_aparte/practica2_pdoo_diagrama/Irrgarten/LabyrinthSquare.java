package Irrgarten;

public class LabyrinthSquare{
	
	private int row;
	private int col;
	private char content;

}
