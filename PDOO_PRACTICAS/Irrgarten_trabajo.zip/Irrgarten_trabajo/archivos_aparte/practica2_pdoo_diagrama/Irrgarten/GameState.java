package Irrgarten;

public class GameState {

	private String labyrinth;
	private String players;
	private String monsters;
	private int currentPlayer;
	private boolean winner;
	private String log;

	public GameState(String labyrinth, String players, String monsters, int currentPlayer, boolean winner, String log) {
		throw new UnsupportedOperationException();
	}
}
