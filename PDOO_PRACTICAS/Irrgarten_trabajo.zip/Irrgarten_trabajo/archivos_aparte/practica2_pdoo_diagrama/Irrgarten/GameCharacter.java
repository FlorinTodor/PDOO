package Irrgarten;

public enum GameCharacter {
	PLAYER, MONSTER
}
