package Irrgarten;

public class Player {
}
