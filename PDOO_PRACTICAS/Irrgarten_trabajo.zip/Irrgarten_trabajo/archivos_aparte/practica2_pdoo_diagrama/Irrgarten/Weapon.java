package Irrgarten;

public class Weapon {

	private float power;
	private int uses;

	public Weapon(float power, int uses) {
		throw new UnsupportedOperationException();
	}

	public float attack() {
		throw new UnsupportedOperationException();
	}

	public boolean discard() {
		throw new UnsupportedOperationException();
	}

	public void operation() {
		throw new UnsupportedOperationException();
	}
}
