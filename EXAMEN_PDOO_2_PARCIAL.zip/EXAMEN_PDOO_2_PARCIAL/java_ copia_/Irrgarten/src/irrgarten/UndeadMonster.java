/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package irrgarten;

/**
 *
 * @author Florin Emanuel Todor
 */
public class UndeadMonster extends Monster{
    private float bonus = Dice.randomStrength();
    private String type = "Undead";
    
    public UndeadMonster(Monster other){
        super(other); 
        this.setPos(other.getRow(), other.getCol());
        setHealth(getInitHealth());
        isUndead();
    }
    
    @Override
    public float attack(){
        return super.attack() + bonus;
    }
    
    @Override
    public String toString(){
        return type +" " + super.toString();
    }
}
