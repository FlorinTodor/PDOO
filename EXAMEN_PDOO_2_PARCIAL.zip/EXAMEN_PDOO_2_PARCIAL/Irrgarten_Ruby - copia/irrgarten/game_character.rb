#encoding:utf-8
#frozen_string_literal: true
module Irrgarten
module Game_character
  PLAYER= :PLAYER
  MONSTER= :MONSTER
end
end