# frozen_string_literal: true
module Irrgarten
  require_relative 'monster'
  require_relative 'dice'
class Undead_monster < Monster
  def copy(other)
    super(other)
  end

  def initialize(other)
    copy(other)
    @bonus = Dice.random_strength
    @health = Monster.get_init_health
    @type = "Undead"
    is_undead
  end

  def attack
    super + @bonus
  end

  def to_s
    @type + " " + super
  end
end
end
